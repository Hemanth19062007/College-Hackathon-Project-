GestureX Starter Package
========================

This is a fresh starter ZIP for troubleshooting the GestureX camera issue.
It is NOT a copy of the original ZIP from your earlier download.

WHAT'S INCLUDED
- index.html: a camera-test page with device selection and clearer error messages.
- README.txt: these instructions.

RUN ON WINDOWS
1. Extract this ZIP (right-click > Extract All).
2. Open the extracted GestureX folder.
3. Click the folder address bar in File Explorer, type cmd, and press Enter.
4. In Command Prompt, run:
       python -m http.server 8000
   If Python is not installed, install Python from python.org or use another local server.
5. Keep the Command Prompt window open.
6. In Edge or Chrome, open:
       http://localhost:8000
7. Click Start camera and allow access.

IMPORTANT
- This package tests camera access. It does not include full hand gesture recognition.
- Camera access generally requires localhost or HTTPS.
- If no camera is detected, check Windows Settings > Privacy & security > Camera,
  and check Device Manager > Cameras.
- Do not share this local address with others; it works on your own computer.
